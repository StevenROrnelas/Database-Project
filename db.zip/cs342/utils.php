<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />    

<link rel="stylesheet" type="text/css" href="style.css" />

<!-- INCLUDE STYLE .css -->
