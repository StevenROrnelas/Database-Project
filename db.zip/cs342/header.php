<?php session_start();
    require_once ('lib.php');

    echo "
        <h2> Basic database access </h2>
        ";
