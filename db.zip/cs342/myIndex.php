<?php session_start();
  require_once ('lib.php');
 ?>
<!DOCTYPE html>
<html>
  <head>
   <style>

   </style>
   
    <title> 342 database </title>
    <?php require_once 'utils.php' ?>
  </head>

<body>
<div id='wrapper' >
   <div id='header'>
      <?php include_once 'header.php' ?>
   </div>

   <div id='left' >
      <?php include_once 'left.php' ?>
   </div>
      <div id='main'>
      
          <h4>Description</h4>
      <p>
          Rough website for 342 database access
      </p>
      
	  <hr>


    </div>  <!-- end main div -->
    
 </div>  <!-- end wrapper div -->
</body>
</html>
