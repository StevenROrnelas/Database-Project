<?php session_start();
    require_once ('lib.php');

    echo "
        <ul>
        <li><a href='myIndex.php'>Home</a></li>
        <li><a href='database.php'>Database</a></li>
        <li><a href='generate.php'>Generate data</a></li>
        </ul> ";
